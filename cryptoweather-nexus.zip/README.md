# 🌐 CryptoWeather Nexus

CryptoWeather Nexus is a dynamic real-time dashboard that combines live **weather**, **cryptocurrency**, and **news** data — with features like **favorites**, **detail views**, and a sleek responsive UI.

Built using:
- 🔥 Next.js 13+ with App Router
- ⚛️ React + Redux Toolkit
- 🌀 Tailwind CSS
- 🧠 WebSockets (CoinCap)
- 🌦 OpenWeatherMap API
- 📰 NewsData.io API
- 🪙 CoinCap REST & WebSocket APIs

...

## 🧑‍💻 Author

Built with ❤️ by **Saitejdeep**  
MIT License
